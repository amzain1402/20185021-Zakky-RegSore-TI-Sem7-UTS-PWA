if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('service-worker.js')
        .then(function (registration) {
            console.log('Service Worker Teregristrasi', registration.scope);
        })
        .catch(function (error) {
            console.log('Service Worker registration failed:', error);
        });
}

//Push Notification
document.addEventListener('DOMContentLoaded', function () {
    // Periksa apakah notifikasi didukung oleh peramban
    if ('Notification' in window) {
        // Meminta izin notifikasi saat halaman dimuat
        Notification.requestPermission()
            .then(function (permission) {
                if (permission === 'granted') {
                    // Izin diberikan, notifikasi dapat dikirim
                    displayNotification();
                    alert('Izin push notification diberikan. Anda akan menerima pemberitahuan.');
                } else if (permission === 'denied') {
                    // Izin diblokir oleh pengguna
                    alert('Izin push notification diblokir. Anda tidak akan menerima pemberitahuan.');
                }
            });
    }

    // Fungsi untuk menampilkan notifikasi
    function displayNotification() {
        const options = {
            body: 'Ini adalah pesan notifikasi.',
            icon: 'Gambar/notif.png', // Ganti dengan lokasi ikon notifikasi Anda
            badge: 'Gambar/badge.png', // Ganti dengan lokasi badge notifikasi Anda
        };
        // Membuat objek notifikasi
        const notification = new Notification('Contoh Notifikasi', options);

        // Menangani interaksi pengguna dengan notifikasi
        notification.onclick = function () {
            alert('Anda mengklik notifikasi.');
        };
    }
});

//indexDB
document.addEventListener('DOMContentLoaded', function () {
    const commentForm = document.getElementById('comment-form');
    const commentInput = document.getElementById('comment');

    commentForm.addEventListener('submit', function (event) {
        event.preventDefault();
        const comment = commentInput.value;

        // Simpan komentar ke IndexedDB
        const request = indexedDB.open('KomentarDB', 1);

        request.onupgradeneeded = function (event) {
            const db = event.target.result;
            db.createObjectStore('comments', { autoIncrement: true });
        };

        request.onsuccess = function (event) {
            const db = event.target.result;
            const transaction = db.transaction('comments', 'readwrite');
            const store = transaction.objectStore('comments');

            store.add({ comment: comment });

            transaction.oncomplete = function () {
                console.log('Komentar berhasil disimpan ke IndexedDB.');
                commentInput.value = '';
            };
        };

        request.onerror = function (event) {
            console.error('Gagal menyimpan komentar ke IndexedDB:', event.target.error);
        };
    });
});

document.getElementById("comment-form").addEventListener("submit", function(event) {
    event.preventDefault();
    
    // Mendapatkan nilai komentar dari textarea
    var commentValue = document.getElementById("comment").value;

    // Menampilkan alert ketika tombol kirim komentar diklik
    if (commentValue.trim() !== "") {
        alert("Komentar Terkirim, Terima Kasih atas Kritik dan Sarannya");
    }
});
